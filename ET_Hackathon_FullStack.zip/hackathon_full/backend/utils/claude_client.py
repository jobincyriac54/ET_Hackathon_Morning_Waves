"""
Anthropic Claude API helpers.

ask()    → returns full text string (one-shot call)
stream() → async generator that yields text chunks for SSE
"""

import os
import anthropic
from typing import AsyncGenerator

# One shared client — reads ANTHROPIC_API_KEY from environment
_client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

MODEL = "claude-sonnet-4-6"


def ask(system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
    """
    Blocking call to Claude.
    Returns the full response text.
    Used by P2 (scan returns JSON, not a stream).
    """
    message = _client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    return message.content[0].text


async def stream_claude(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 1500,
) -> AsyncGenerator[str, None]:
    """
    Async generator — yields raw text chunks from Claude's streaming API.
    The FastAPI route wraps these chunks into SSE format.

    Usage inside a route:
        async for chunk in stream_claude(system, user):
            yield f"data: {json.dumps({'chunk': chunk})}\\n\\n"
    """
    with _client.messages.stream(
        model=MODEL,
        max_tokens=max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    ) as stream:
        for text_chunk in stream.text_stream:
            yield text_chunk
