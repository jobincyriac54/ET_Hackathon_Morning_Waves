"""
Problem 4 — GridMind: Autonomous Renewable Energy Orchestrator
Endpoints (all stream SSE):
  POST /api/p4/scenario  → Real-world scenario response with dispatch actions
  POST /api/p4/query     → Free-form agent question
  POST /api/p4/optimize  → Full dispatch optimization for current state
  POST /api/p4/forecast  → 24-hour energy simulation
"""

import json
from typing import Optional
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from utils.claude_client import stream_claude

router = APIRouter(prefix="/api/p4", tags=["P4 Energy"])

# ── System prompt ──────────────────────────────────────────────
SYSTEM = """You are GridMind AI, an autonomous renewable energy orchestrator managing:
- 5 solar farms: SF1 Rajasthan (100MW), SF2 Gujarat (120MW), SF3 Andhra (80MW),
  SF4 Tamil Nadu (90MW), SF5 Maharashtra (80MW)
- 3 wind farms: WF-A Kutch (90MW), WF-B Tamil Nadu Coast (75MW), WF-C Rajasthan (60MW)
- 2 battery energy storage systems: BESS Alpha (200MWh), BESS Beta (150MWh)
- Industrial consumers: Steel Plant 120MW, Cement Plant 85MW, Data Center 45MW, Chemical 62MW
- Grid interconnections and electricity market access

You dispatch decisions every 15 minutes. Objective priority (highest to lowest):
1. Grid Reliability   2. Carbon Minimisation   3. Cost Minimisation
4. Revenue Maximisation   5. Battery Longevity   6. Renewable Curtailment Minimisation

Use Indian energy market: ₹/kWh prices, MW/MWh units. Be specific and quantified in all responses."""


# ── SSE helper ─────────────────────────────────────────────────
async def sse_stream(system: str, user: str, max_tokens: int = 1500):
    async for chunk in stream_claude(system, user, max_tokens):
        yield f"data: {json.dumps({'chunk': chunk})}\n\n"
    yield f"data: {json.dumps({'done': True})}\n\n"


def streaming_response(system: str, user: str) -> StreamingResponse:
    return StreamingResponse(
        sse_stream(system, user),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


# ── Grid state model (used across multiple endpoints) ──────────
class GridState(BaseModel):
    solar: float = 342.0          # MW current solar output
    wind: float = 187.0           # MW current wind output
    batAlpha: float = 72.0        # BESS Alpha SOC %
    batAlphaStatus: str = "Charging 40MW"
    batBeta: float = 61.0         # BESS Beta SOC %
    batBetaStatus: str = "Standby"
    demand: float = 498.0         # MW grid demand
    price: float = 4.2            # ₹/kWh market price
    transmission: float = 62.0    # % of transmission line capacity used
    surplus: float = 31.0         # MW surplus (positive) or deficit (negative)
    storm: str = "None"           # Storm/weather alert status


class ScenarioRequest(BaseModel):
    scenario: str                 # Description of the real-world event
    gridState: Optional[GridState] = None


class QueryRequest(BaseModel):
    question: str
    gridState: Optional[GridState] = None


class OptimizeRequest(BaseModel):
    gridState: Optional[GridState] = None
    objectives: Optional[list] = None


class ForecastRequest(BaseModel):
    gridState: Optional[GridState] = None
    weatherForecast: str = "Sunny morning, partial cloud 14:00-17:00, wind increasing after 18:00, no storms"


# ── Helper: format grid state for prompts ──────────────────────
def format_grid_state(gs: Optional[GridState]) -> str:
    if not gs:
        return "Grid state: Solar 342MW, Wind 187MW, BESS Alpha SOC 72%, BESS Beta SOC 61%, Demand 498MW, Price ₹4.2/kWh, Surplus +31MW, Storm: None"
    return f"""Current Grid State:
  Solar output:        {gs.solar} MW
  Wind output:         {gs.wind} MW
  BESS Alpha:          SOC {gs.batAlpha}% — {gs.batAlphaStatus}
  BESS Beta:           SOC {gs.batBeta}% — {gs.batBetaStatus}
  Grid demand:         {gs.demand} MW
  Market price:        ₹{gs.price}/kWh
  Transmission load:   {gs.transmission}%
  Surplus / Deficit:   {'+' if gs.surplus >= 0 else ''}{gs.surplus} MW
  Storm alert:         {gs.storm}
  Total renewable:     {gs.solar + gs.wind} MW
  Renewable cover:     {round((gs.solar + gs.wind) / gs.demand * 100, 1)}%"""


# ── Routes ─────────────────────────────────────────────────────

@router.post("/scenario")
async def scenario(req: ScenarioRequest):
    """
    Real-world scenario response — the core agentic capability.

    What it does:
    - Receives a real-world event (cloud covers solar, wind spike, price spike,
      battery failure, demand surge, transmission limit, storm alert, etc.)
    - Reads current grid state
    - Reasons through the situation with multi-objective awareness
    - Dispatches specific actions: charge/discharge MW, buy/sell MW at ₹/kWh,
      curtail generation, trigger demand response
    - Simulates the next 24 hours

    Why this is F3:
    - F1: Optimal action cluster selected ✓
    - F2: Optimality criteria determined per situation + uncertainty adjustment ✓
    - F3: Simulates situation over 24 hours across varying input conditions ✓

    Why this is D3:
    - Inputs come from SCADA telemetry, weather APIs, market feeds, battery BMS —
      all heterogeneous real-time data sources, handled with high reliability
    """
    state_str = format_grid_state(req.gridState)

    user = f"""SCENARIO EVENT: {req.scenario}

{state_str}

As GridMind AI, respond to this scenario with full autonomous agent reasoning:

1. SITUATION ASSESSMENT
   - What exactly changed and why it matters
   - Immediate risk or opportunity created
   - Time window available to act before conditions worsen

2. DISPATCHED ACTIONS — List 4-6 specific actions being executed RIGHT NOW:
   For each action state the exact quantity, the asset/market, the ₹ impact, and the reason:
   - Battery: charge/discharge X MW from BESS [Alpha/Beta] (reason + revenue/cost impact)
   - Market: buy/sell X MW at ₹X/kWh (reason + timing)
   - Generation: curtail X farm by X MW (reason — why curtail rather than store or sell?)
   - Demand: trigger demand response for [consumer], reduce X MW (incentive ₹/MWh)

3. MULTI-OBJECTIVE TRADE-OFF
   - Which competing objectives are in conflict in this specific scenario?
   - How was the conflict resolved? (e.g., reliability prioritised over revenue)
   - What is the cost of that priority decision in ₹?

4. 24-HOUR SIMULATION — What happens across 4 time windows:
   Next 15 minutes: [actions and expected outcomes]
   Next 1 hour:     [actions and expected outcomes]
   Next 4 hours:    [actions and expected outcomes]
   Next 24 hours:   [actions and expected outcomes, including recovery plan]

5. RISK ASSESSMENT
   - What could still go wrong even with these actions?
   - What contingency actions are pre-armed and at what trigger threshold?

6. METRICS IMPACT — Quantify the effect of these actions on:
   - Operating cost (₹/hr change)
   - Revenue today (₹ change)
   - CO₂ saved (tonnes change)
   - Battery degradation (cycle impact)
   - Grid reliability (frequency stability %)"""

    return streaming_response(SYSTEM, user)


@router.post("/query")
async def query(req: QueryRequest):
    """
    Free-form agent query.

    What it does: Answers any energy management question in the context of the
    current grid state. Useful for live demo — the evaluator can ask the agent
    anything and get a specific, quantified answer.

    Examples:
    - "Should I sell now or wait for the 15:15 price spike?"
    - "What is optimal battery strategy for the next 4 hours?"
    - "Run a 24h simulation for tomorrow with the storm approaching"
    - "How do I trade off battery degradation vs revenue today?"
    """
    state_str = format_grid_state(req.gridState)

    user = f"""{state_str}

Question from grid operator: {req.question}

Provide a specific, quantified answer:
- Use MW, MWh, ₹/kWh, % units throughout
- Show your reasoning (why this recommendation vs alternatives)
- Include any trade-offs the operator should be aware of
- State any assumptions you are making about future conditions
- If the question involves a decision, state the exact recommended action"""

    return streaming_response(SYSTEM, user)


@router.post("/optimize")
async def optimize(req: OptimizeRequest):
    """
    Full dispatch optimization for the current 15-minute window.

    What it does:
    - Takes the complete current grid state
    - Evaluates the action space across all 5 action categories
    - Selects the optimal action set balancing all 6 objectives
    - Provides 2 alternative strategies with different objective trade-offs
    - Scores each objective for the selected strategy
    - States what triggers the next re-optimization

    This is the core F2 → F3 transition:
    - F2: Determines optimality criteria based on situation + adjusts for uncertainty
    - F3: Simulates over time (the 24h forward look) with input variations
    """
    state_str = format_grid_state(req.gridState)
    obj_str = ", ".join(req.objectives) if req.objectives else "Reliability > Carbon > Cost > Revenue > Battery Longevity"

    user = f"""Run full dispatch optimization for this 15-minute window:

{state_str}

Objective priority: {obj_str}

Provide:

1. OPTIMAL ACTION SET — Exact dispatch for the next 15 minutes:
   List every action with asset name, quantity (MW), duration, and financial impact (₹)

2. OBJECTIVE SCORES — How well does the optimal action set perform on each objective?
   Rate each 0-100:
   - Grid Reliability: X/100 (reasoning)
   - Carbon Minimisation: X/100 (reasoning)
   - Cost Minimisation: X/100 (reasoning)
   - Revenue Maximisation: X/100 (reasoning)
   - Battery Longevity: X/100 (reasoning)

3. TWO ALTERNATIVE STRATEGIES with different trade-offs:
   Strategy A: [Name — e.g., "Maximum Revenue Focus"]
   - Actions: [list]
   - Trade-off: [what is sacrificed vs optimal]
   - Objective scores: [how it compares]

   Strategy B: [Name — e.g., "Maximum Carbon Reduction"]
   - Actions: [list]
   - Trade-off: [what is sacrificed vs optimal]
   - Objective scores: [how it compares]

4. UNCERTAINTY ADJUSTMENT
   - What are the top 3 uncertain inputs (weather / price / demand)?
   - How does the optimal strategy perform in the worst-case uncertainty scenario?
   - Is the strategy robust or does it need a contingency?

5. NEXT DECISION POINT
   - What specific event or threshold triggers the next re-optimization before the
     scheduled 15-minute window?"""

    return streaming_response(SYSTEM, user)


@router.post("/forecast")
async def forecast(req: ForecastRequest):
    """
    24-hour energy portfolio simulation.

    What it does:
    - Projects generation (solar/wind) hour by hour using weather forecast
    - Projects demand and market prices hour by hour
    - Plans the battery charge/discharge schedule optimized for revenue and reliability
    - Plans market buy/sell actions at optimal times
    - Shows renewable utilization vs curtailment each hour
    - Summarizes daily totals

    This is the F3 simulation capability:
    "Simulate situation/scenario over a period of time by accounting for
    potential variations in the input conditions"
    """
    state_str = format_grid_state(req.gridState)

    user = f"""Run 24-hour energy portfolio simulation:

{state_str}
Weather forecast: {req.weatherForecast}

Simulate hour by hour for the next 24 hours:

1. HOURLY GENERATION TABLE (key hours, not all 24 — group similar hours):
   | Hour | Solar MW | Wind MW | Total Gen | Demand MW | Price ₹/kWh | Balance |
   Include at minimum: 06:00, 09:00, 12:00, 15:00, 18:00, 21:00, 00:00, 03:00

2. BATTERY DISPATCH SCHEDULE — Optimized charge/discharge plan:
   - When to charge BESS Alpha (hours, MW rate, reason)
   - When to discharge BESS Alpha (hours, MW rate, reason)
   - BESS Beta role (standby/emergency reserve/active cycling)
   - Target SOC at end of day and why

3. MARKET ACTIONS — When to buy and when to sell:
   - Sell windows: [times, quantities, expected prices, ₹ revenue]
   - Buy windows (if any): [times, quantities, prices, reason]
   - Total revenue from market actions ₹

4. RENEWABLE UTILIZATION — For each major time block:
   - % of available renewables used
   - MW curtailed (if any) and why
   - Strategy to minimize curtailment

5. DAILY SUMMARY:
   - Total revenue ₹
   - Total operating cost ₹
   - Net margin ₹
   - CO₂ saved (tonnes vs fossil baseline)
   - Battery SOC at day end
   - Renewable utilization %
   - Grid reliability maintained: Yes/No"""

    return streaming_response(SYSTEM, user)
